define(["jquery","jquery-cookie"],function($){
	
	var list = function(){
		
		$(function(){
			/* 导航条部分 */
			$.ajax({
				url:"data/data3.json",
				success:function(arr){
					/*分页部分*/
					var page = Math.ceil(arr.length / 12);
					var curPage =$(".ui_page_curr").html();
					
					
					//调用绘制分页样式函数
					draw(page,curPage);
					//绑定点击页码
					$(document).on('click','#pager a',function(){
						var str = $(this).html();
						if(!isNaN(str)){
							var content1 = $('.ui_page_curr').html();
							var new1 = $("<a href=''>" + content1 + '</a>');
							new1.after$('.ui_page_curr');
							$('.ui_page_curr').remove();
							
							
							var content2 = $(this).html();
							var new2 = $("<span class='ui_page_curr'>" + content2 + '</span>');
							new2.after($(this));
							$(this).remove();
						}
					})
					//绑定下一页点击事件
					$(document).on("click",".ui_page_next",function(){
						var num = $('.ui_page_curr').html();
						var page = Math.ceil((parseInt(num)) / 12);
						if(num < page * 12 && num !='末页'){
							//移除之前的.ui_page_curr
							var content1 = $('.ui_page_curr').html();
							var new1 = $("<a href=''>" + content + '</a>');
							new1.after$('.ui_page_curr');
							$('.ui_page_curr').remove();
							
							var content2 = num + 1;
							var new2 = $("<span class=''>" + content2 + '</span>');
							new2.after($(this));
							$(this).remove();
							
						}
						
					})
					
					
					
					
					for(var i = 0;i < arr.length;i++){
						
						if(arr[i].price2){
							$(`<li class="mob_pro  ">
								<a href="javascript:;" class="ui_pimg" target="_blank">
								<img src="${arr[i].img}" alt="${arr[i].name}" width="300" height="300">
								</a>
								<p class="ui_pname">
								<a href="javascript:;" target="_blank">${arr[i].name}<span class="ui_pslogan">${arr[i].detail}</span></a>
								</p>
								<div class="mask" style="display: none;">
								<p class="charator">${arr[i].detail}</p>
								<a href="javascript:;" target="_blank" class="view">查看详情</a>
								</div>
								<p class="ui_price"><span class="ui_pprice"><em>¥</em><span>${arr[i].price1}</span></span><span class="ui_pprice_m"><em>¥</em><del>${arr[i].price2}</del></span></p>
								</li>`).appendTo($('#JmobileList'));
						}else{ 
							$(`<li class="mob_pro  ">
								<a href="javascript:;" class="ui_pimg" target="_blank">
								<img src="${arr[i].img}" alt="${arr[i].name}" width="300" height="300">
								</a>
								<p class="ui_pname">
								<a href="javascript:;" target="_blank">${arr[i].name}<span class="ui_pslogan">${arr[i].detail}</span></a>
								</p>
								<div class="mask" style="display: none;">
								<p class="charator">${arr[i].detail}</p>
								<a href="javascript:;" target="_blank" class="view">查看详情</a>
								</div>
								<p class="ui_price"><span class="ui_pprice"><em>¥</em><span>${arr[i].price1}</span></span></p>
								</li>`).appendTo($('#JmobileList'));
						} 
						
					
					}
				}
			})
			
			
			function selectPage(){
				var curPage =$(".ui_page_curr").val();
				
			}
		
			
	/* 结尾 */
		}
	)}
	
	
	return {
		list : list
	}
})			