define(["jquery","jquery-cookie"],function($){
	
	var main = function(){
		
		
		$(function(){
			
			
			/* 导航条部分 */
			$.ajax({
				url:"data/data1.json",
				success:function(arr){
					for(var i = 0;i < arr.length;i++){
						$(`<div class="menu-li">
											<div class="menu-ul" >
												<ul style="width:100%">
													<li>
														<span style="width:50px;">&nbsp;</span>
													</li>
													<li>
														<a href="#">
															<span style="font-weight:bold;">
																<font font="" size="3px" color="#777777">${arr[i][0].model} &gt;</font>
															</span>
														</a>
													</li>
													<table>
														<tbody>
															<tr>
																<td style="width:100%;height:10px;font-size:14px;border:0">
																</td>
															</tr>
														</tbody>
													</table>
												</ul>
											</div>`).appendTo($('.menu-box'));
						for(var j = 0;j<arr[i].length;j++){
							$(`<li><a class='${arr[i][j].class}' href="#">${arr[i][j].value}</a></li>`).appendTo($('.menu-box .menu-li:last-child .menu-ul ul'));
						}
					}
				}
			})
			/*轮播图部分*/
			
			function Slider(){
				let oBigBox = document.querySelector('#bannerslide');
				//获取上半部分
				//获取左按钮
				let oLeftBtn = document.querySelector('.arrowleft');
				//获取右按钮
				let oRightBtn = document.querySelector('.arrowright');
				//获取所有大图
				let oBigPics = document.querySelectorAll('.banner li');
				//获取底部按钮
				let oSmallLis = document.querySelectorAll('.menu-page ul li');
				//定义一个控制图片轮播的下标
				let indexA = 0;
				//定义一个改变z-index的变量
				let zIndex = 1;
				//记录计时器
				let timer = null;
				slider();
				autoPlay();
				//给左右按钮添加点击事件
				oLeftBtn.onclick = function(){
					indexA-- ;
					if(indexA == -1){
						indexA = oBigPics.length -1;
					}
					slider();
				}
				oRightBtn.onclick = function(){
					indexA ++;
					if(indexA == oBigPics.length){
						indexA = 0;
					}
					slider();
				}
				//给按钮添加事件
				for(let i =0,len = oSmallLis.length;i < len;i++){
					
					//点击时，轮播到当前点击的图片
					oSmallLis[i].onclick = function(){
						indexA = i;
						slider();
						//改变样式
						$('.menu-page ul li').attr('class','');
						$(this).attr('class','on');
					}
				}
				
				//设置轮播
				function slider(){
					//大图轮播
					/* oBigPics.css('display','none');
					oBigPics[indexA].css('display','list-item'); */
					$('.banner li').animate({
						opacity:0.5
					},function(){
						$(this).css(
							'display','none'
						)
					});
					$('.banner li'+':eq(' + indexA+')').animate({
						opacity:1
					},function(){
						$(this).css(
							'display','list-item'
						)
					});;
					//小图轮播
					$('.menu-page ul li').attr('class','');
					$('.menu-page ul li'+ ':eq(' + indexA+')').attr('class','on');
				}
				
				//自动轮播
				function autoPlay(){
					timer = setInterval(function(){
						indexA ++;
						if(indexA == oBigPics.length){
							indexA = 0;
						}
						slider();
						
					},2000)
				}
				//给大盒子添加移入移除事件
				oBigBox.onmouseenter = function(){
					clearInterval(timer);
				}
				oBigBox.onmouseleave = function(){
					autoPlay();
				}
			}
			Slider();
		
		/* 明星产品部分 */
		$.ajax({
			url:"data/data2.json",
			success:function(arr){
				for(var i = 0;i < arr.length;i++){
					$(`<li class="nopadding">
							<a href="javascript:;" target="_blank">
							<img src='${arr[i].img}' alt='${arr[i].tit0}'>
								<div class="hr-des">
									<p class="hr-title">&nbsp;</p>
									<p class="hr-detail"><span class="hr-circle">.</span>${arr[i].tit1}</p>
									<p class="hr-detail"><span class="hr-circle">.</span>${arr[i].tit2}</p>
									<p class="hr-detail"><span class="hr-circle">.</span>${arr[i].tit3}</p>
								</div>
							</a>
						</li>`).appendTo($('.sp-list'));
					
				}
			}
		})
		
		/*热卖产品*/
		$.ajax({
			url:"data/data3.json",
			success:function(arr){
				for(var i = 0;i < arr.length;i++){
					$(`<li>
					<a href="javascript:;" target="_blank">
						<div class="hr-phoneimg">
						<img class="after" src='${arr[i].img1}' alt="">
						<img class="before" src='${arr[i].img2}' alt="">
						</div>
						<div class="hr-des">
							<p class="hr-title">${arr[i].title}</p>
							<p class="hr-detail">${arr[i].detail}</p>
							<p class="hr-price">
							<span class="hr-money">¥</span>${arr[i].price}
							<span style="font-size: 18px;"></span>
							</p>
						</div>
					</a>
				</li>`).appendTo($('.hr-right'));
					
				}
			}
		})
		/*精美配件*/
		$.ajax({
			url:"data/data4.json",
			success:function(arr){
				for(var i = 0;i < arr.length;i++){
					$(`<li>
							<a href="javascript:;" target="_blank">
								<img src='${arr[i].img}' alt="金立 数据线">
								<div class="hr-des">
									<p class="hr-title">${arr[i].title}</p>
									<p class="hr-detail">${arr[i].detail}</p>
									<p class="hr-price">
									<span class="hr-money">¥</span>${arr[i].pirce}
									</p>
								</div>
							</a>
						</li>`).appendTo($('.eas'));
				}
			}
		})
		
		/* 结尾 */
		}
	)}
	
	
	return {
		main : main
	}
})